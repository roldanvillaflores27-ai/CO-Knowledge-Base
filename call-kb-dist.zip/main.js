
document.getElementById('root').innerText = 'This is a placeholder build. Run npm run build locally for the full app.';
